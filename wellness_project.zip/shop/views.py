from django.shortcuts import render, redirect
from .models import Product
from django.conf import settings

def home(request):
    products = Product.objects.all()
    return render(request, "home.html", {"products": products})

def checkout(request):
    products = Product.objects.all()
    total = sum(p.price for p in products)
    return render(request, "checkout.html", {"products": products, "total": total, "stripe_pub": settings.STRIPE_PUBLISHABLE_KEY})

def success(request):
    return render(request, "success.html")
