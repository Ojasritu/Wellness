# Run this after migrations and after activating venv:
# python manage.py shell < create_demo.py
from shop.models import Product
p, created = Product.objects.get_or_create(
    name="Ojasritu Herbal Capsule - Demo",
    defaults={
        "description": "Demo herbal wellness capsule. Buy one, feel refreshed. (Demo product)",
        "price": "199.00",
    }
)
if not p.image:
    p.image = "products/demo.jpg"
    p.save()
print("Demo product created:", p.name)
