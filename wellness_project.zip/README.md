# Ojasritu Wellness - Django Starter (Demo)

This is a demo Django e-commerce starter project (small, easy to run).

## Quick start (Codespaces)
1. Create a GitHub repo and upload this zip.
2. Open Codespaces (Create codespace on main).
3. In the Codespaces terminal:
   unzip wellness_project.zip
   rm wellness_project.zip
   cd wellness_project
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   python manage.py migrate
   python manage.py createsuperuser
   python manage.py shell < create_demo.py
   python manage.py runserver 0.0.0.0:8000

4. Open Ports tab → 8000 → Open in Browser.
5. Admin: /admin/ → login with superuser and add products.

## Notes
- Demo checkout is a simple demo page (doesn't actually call Stripe backend).
- To enable full Stripe Checkout, add your Stripe test keys to wellness_project/settings.py.
